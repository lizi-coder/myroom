#pragma once

namespace net
{

namespace socket
{

    int CreateSocket();


}


}   ///< END OF namespace net



