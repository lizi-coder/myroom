#include <iostream>
#include"bases/Logging.h"

using namespace base;
int main()
{
    LOG_DEBUG<<"hello";
    std::cout << "Hello world" << std::endl;
    return 0;
}

